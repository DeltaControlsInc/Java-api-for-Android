var a00022 =
[
    [ "connect", "a00022.html#ga318c59dfe5f33610fc635a566784371e", null ],
    [ "connect", "a00022.html#gab18c306c2d5c1a643333e36cdddccdfa", null ],
    [ "disconnect", "a00022.html#ga960705de531a20389fb29928d43258c3", null ],
    [ "setLoginParams", "a00022.html#gafb4525b3d789e727858cd428e9884402", null ]
];