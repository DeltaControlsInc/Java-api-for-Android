var a00021 =
[
    [ "CONNECTION_STATUS", "a00005.html", [
      [ "ERROR_INVALID_APPS_LICENSE", "a00005.html#af5d9748ac16e2a8c3cfa52da136cded6", null ],
      [ "ERROR_LOGIN_PASSWORD", "a00005.html#a7d7a7db5e73f9b66a23606db86d6001f", null ],
      [ "ERROR_NETWORK", "a00005.html#a567e4c039f956031f4af0cc472342c94", null ],
      [ "ERROR_NO_CONNECTION_AVAILABLE", "a00005.html#a42ce10fa1ec9e46d2486ad8b72dbd8d0", null ],
      [ "ERROR_UNKNOWN_EXCEPTION", "a00005.html#a944695a18fb837dcf58dbf18f0ff4540", null ],
      [ "ERROR_UNKNOWN_URL", "a00005.html#af9770ecef58fba3e41705f2f07f5877d", null ],
      [ "NOT_INITIALIZED", "a00005.html#a25f92fd1cdfdf90f3291962ec234b760", null ],
      [ "OK", "a00005.html#a509f04652b5e1b2d2b9e6bc121a87e50", null ]
    ] ],
    [ "EwebConnection", "a00021.html#ga6dc03793006f6370c82bc469dac65796", null ],
    [ "getConnectionStatus", "a00021.html#gabee4c9212416f9410d5e7048614f4f42", null ],
    [ "getServerURL", "a00021.html#gaf9d56b11eaf7a394a6180d780ff19c6a", null ],
    [ "isConnected", "a00021.html#gafbf4768f0408a85337dbb9f1413d611a", null ],
    [ "userLocale", "a00021.html#gad7413e5496d8371c0534e4d56de308ee", null ]
];