var a00025 =
[
    [ "AlarmGroup data model", "a00026.html", "a00026" ],
    [ "iEvent data model", "a00030.html", "a00030" ],
    [ "iAlarmDetails data model", "a00031.html", "a00031" ],
    [ "iEvent List data model", "a00032.html", "a00032" ],
    [ "acknowledgeEvent", "a00025.html#ga1c2d5fd200fa000dae617f9278c88a7d", null ],
    [ "getAlarmDetails", "a00025.html#gaced5b26065b50249cebda946601b5440", null ],
    [ "getEventList", "a00025.html#ga0799e40adb0e272a522f937b894cd3fe", null ],
    [ "getNextEventList", "a00025.html#gaa722b346cc57737d93001e5728f918ce", null ],
    [ "setAlarmDetails", "a00025.html#gad5fe5a66052d23d4fde9495255f01803", null ]
];