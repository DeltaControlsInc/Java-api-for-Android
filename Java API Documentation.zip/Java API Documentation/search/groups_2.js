var searchData=
[
  ['delta_5fiauth',['Delta_IAuth',['../a00022.html',1,'']]],
  ['delta_5fidotmulti',['Delta_Idotmulti',['../a00023.html',1,'']]],
  ['delta_5fievent',['Delta_IEvent',['../a00025.html',1,'']]],
  ['delta_5fiviews',['Delta_IViews',['../a00024.html',1,'']]]
];
