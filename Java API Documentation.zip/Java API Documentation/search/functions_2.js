var searchData=
[
  ['connect',['connect',['../a00022.html#ga318c59dfe5f33610fc635a566784371e',1,'EwebConnection.connect(String newHost, String newName, String newPass, final GenericCallback&lt; FetchJSON.Result &gt; fetchListener, final boolean basicAuthentication)'],['../a00022.html#gab18c306c2d5c1a643333e36cdddccdfa',1,'EwebConnection.connect(String newHost, String newName, String newPass, final GenericCallback&lt; FetchJSON.Result &gt; fetchListener)']]]
];
