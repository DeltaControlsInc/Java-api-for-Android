var searchData=
[
  ['color',['color',['../a00026.html#ga8117c055eb6d26551bf4d3e25281e6da',1,'AlarmGroup']]],
  ['count',['count',['../a00026.html#gad43c3812e6d13e0518d9f8b8f463ffcf',1,'AlarmGroup']]],
  ['currentstate',['currentState',['../a00030.html#gab9def809688df46ac64d6ab079013046',1,'iEvent']]]
];
