var searchData=
[
  ['fromjson',['fromJson',['../a00032.html#gac0ea91356b4a83fff1ec4425e9223339',1,'iEventList.fromJson(String jsonStr)'],['../a00032.html#ga03ffcbf5b368920a99efa7871e3f1e9c',1,'iEventList.fromJson(JSONObject jsonObj)']]]
];
