var a00026 =
[
    [ "AlarmGroup", "a00026.html#gad997e89a40bf73af43220374a2670b4a", null ],
    [ "AlarmGroup", "a00026.html#gab601bf614a232d50f0109a51a0e411dc", null ],
    [ "color", "a00026.html#ga8117c055eb6d26551bf4d3e25281e6da", null ],
    [ "count", "a00026.html#gad43c3812e6d13e0518d9f8b8f463ffcf", null ],
    [ "name", "a00026.html#ga9a2326f35466e54c36c070829245c557", null ],
    [ "sound", "a00026.html#ga52fe5c65b62a0d167baf31109d0422f2", null ]
];