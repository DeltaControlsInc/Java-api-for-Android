var a00032 =
[
    [ "fromJson", "a00032.html#gac0ea91356b4a83fff1ec4425e9223339", null ],
    [ "fromJson", "a00032.html#ga03ffcbf5b368920a99efa7871e3f1e9c", null ],
    [ "iEventList", "a00032.html#gad97b373557ba0fc4e34a61bcf0314409", null ],
    [ "iEventList", "a00032.html#gaa4634a52b341067c19638e8edb9718a1", null ],
    [ "events", "a00032.html#ga1728b241c8834d6049fd3233fe071f5b", null ],
    [ "next", "a00032.html#gaebb8fecfed5d031019fc1a3cba4a00d5", null ]
];