var a00028 =
[
    [ "BACnetObjectValue", "a00028.html#gacc30640ac2382a5179027c3f8ffd28db", null ],
    [ "BACnetObjectValue", "a00028.html#ga2957e6e47e4eef39c99703fa6766c433", null ],
    [ "dataType", "a00028.html#ga887351c69c9914db17f92bf1409ccb28", null ],
    [ "errorText", "a00028.html#ga8e2430a03a1c864961ca922164880307", null ],
    [ "priority", "a00028.html#ga2bf6b2113d0fb44317380820d3814e0b", null ],
    [ "value", "a00028.html#ga32147dacf0dd0bda3c39144c67347bf3", null ],
    [ "valueFormatted", "a00028.html#ga5cd0715fdf28e595d001e8a7a7b6720e", null ],
    [ "via", "a00028.html#ga146405440b993179cfb2d94aaa51caad", null ]
];