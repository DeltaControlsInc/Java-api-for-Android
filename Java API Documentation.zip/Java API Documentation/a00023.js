var a00023 =
[
    [ "BACnetObjectReference data model", "a00027.html", "a00027" ],
    [ "BACnetObjectValue data model", "a00028.html", "a00028" ],
    [ "BACnetObjectValueList data model", "a00029.html", "a00029" ],
    [ "getMulti", "a00023.html#ga72936147e94e951f9a53a583fdc21ecf", null ],
    [ "putMulti", "a00023.html#ga7fa29d9e7c1551657f20f16915217823", null ]
];