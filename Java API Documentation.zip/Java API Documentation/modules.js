var modules =
[
    [ "EwebConnection", "a00021.html", "a00021" ],
    [ "Delta_IAuth", "a00022.html", "a00022" ],
    [ "Delta_Idotmulti", "a00023.html", "a00023" ],
    [ "Delta_IViews", "a00024.html", "a00024" ],
    [ "Delta_IEvent", "a00025.html", "a00025" ]
];