var a00027 =
[
    [ "Type", "a00012.html", [
      [ "BACNET", "a00012.html#a660fbd6a27f144c9b6ec2ceb8f394096", null ],
      [ "EWEB", "a00012.html#a9aa5138ab2be7d828989bbab481767e8", null ]
    ] ],
    [ "BACnetObjectReference", "a00027.html#gad27e2f25097188ad9d105b6eebdaf3f6", null ],
    [ "BACnetObjectReference", "a00027.html#gafac746087eb294f1345a633b304402b3", null ],
    [ "toString", "a00027.html#gadce66f066d379968fa52c7b2cc5bfa9c", null ],
    [ "toString", "a00027.html#gaf7c0990a62f4779ffb7104a8bb3c017b", null ],
    [ "device", "a00027.html#gaf4fd174ed9d83547e844a24fb16d03a3", null ],
    [ "instance", "a00027.html#gaa3efd9c1ff7fc79ba646125dbb9d0fca", null ],
    [ "object", "a00027.html#gab22da75ede7e500ec9053c341afd1cdd", null ],
    [ "property", "a00027.html#ga8ca5125f57ad5d24db38cd6f845550fc", null ],
    [ "site", "a00027.html#ga6c19ad561b0fb53b0aa8bed4174a288b", null ]
];